package com.rbr.proyectofinal.ui.navigation

enum class Screens {
    SplashScreen,
    LoginScreen,
    HomeScreen,
    ProfileScreen
}
